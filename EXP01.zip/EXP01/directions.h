//
// Created by felipe.domingues on 10/5/19.
//

#ifndef BATMANAGER_DIRECTIONS_H
#define BATMANAGER_DIRECTIONS_H

#define NORTH 0;
#define EAST 1;
#define SOUTH 2;
#define WEST 3;


char directionToChar(int direction);
int charToDirection(char direction);

#endif //BATMANAGER_DIRECTIONS_H
